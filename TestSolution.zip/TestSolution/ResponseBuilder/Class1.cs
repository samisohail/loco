﻿namespace ResponseBuilder
{
    public class Class1
    {

    }
}