﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web.Setup
{
    //public class BaseController : ApiController
    //{
    //}
}
